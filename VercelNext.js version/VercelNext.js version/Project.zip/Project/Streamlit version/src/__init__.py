# Resume Analyzer Package
__version__ = "1.0.0"
__author__ = "Your Name"
__description__ = "AI-powered resume analysis and skill extraction system"
